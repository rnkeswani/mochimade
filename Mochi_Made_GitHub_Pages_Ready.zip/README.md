# Mochi Made — Website

This repository hosts the Mochi Made static shop preview on GitHub Pages.

## Publish with GitHub Pages
1. Create a public GitHub repository, for example `mochi-made`.
2. Upload `index.html` to the **root** of the repository (not inside a folder).
3. Open **Settings > Pages > Build and deployment**.
4. Select **Deploy from a branch**, then **main** and **/(root)**, and click **Save**.
5. After deployment, GitHub will show the website URL in **Settings > Pages**.

The uploaded product photographs are embedded inside `index.html`, so you do not need a separate image folder.

## Important: Orders
GitHub Pages hosts static HTML/CSS/JavaScript; **this upload does not send or store real orders**.
The store currently supports category filters, a shopping basket, item totals and a checkout *preview*.
To receive real orders via the Mochi Made Google account, connect a secure external ordering backend.
The original download contains `Code.gs`, a Google Apps Script backend intended for a separately hosted Google Apps Script web app. The current site's `google.script.run` branch only works **inside** an Apps Script web app, not on GitHub Pages. Do not publish customer details or Google account credentials in your GitHub repository.

## Before selling
Confirm MakerWorld commercial-use permission for each 3D-printed model. Review product photographs and print suitability (particularly for items touching hot food/drinks). Enable two-factor authentication on the shop account.
